Bootstrap-Arrows
================

A simple add-on to the popular Twitter Bootstrap framework to include the use of arrows in your UI designs.

Go to http://bootstrap-arrows.iarfhlaith.com for a demo and example usage code.