(function ($) {
  $(document).ready(function() {
    $('.row-toggle').removeClass('row').addClass('row-fluid');
  });
})(jQuery);
